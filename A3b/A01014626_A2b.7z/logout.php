<?php
require ("includes/functions.php");
session_start();
logout('login.php');

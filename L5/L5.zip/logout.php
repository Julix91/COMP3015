<?php
require ("includes/functions.php");
logout('lab5.php');

<?php
require ("includes/functions.php");
logout('login.php');
